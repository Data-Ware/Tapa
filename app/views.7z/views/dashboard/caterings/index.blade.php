@extends('dashboard.master')
@section('content')
<div>
<h2>Catering Menu</h2>
<h4  href="" <span class="glyphicon glyphicon-pencil btn btn-success ">Edit Categorie</span> 
       </h4>
</div>
<div class="col-md-9">

<div>	
<div><a href="" class="btn btn-success">Add block</a></div>
</div>
<table border="1">
		<thead>
			<tr>
				
				<th>Categorie</th>
				<th>Decription</th>
				<th>ID Block</th>
				<th>Edit</th>
				<th>Delete</th>
			
			
	 	    <!--[$block, $cat];-->


			</tr>
		</thead>

	<tbody>
		
@foreach($itemsCat as $item)
			<tr>
				<td>{{ $item->id_cat }}</td>
				<td>{{ $item->desc }}</td>
				<td>{{ $block->id_cat }}</td>
				

				<td><a href="{{ URL::to('caterings/'. $item->id_cat.'/edit') }}" class="btn btn-primary">Edit</a></td>
			
				<td>
					
					{{ Form::open(array('url' => 'caterings/' . $item->id_cat)) }}
					<button class='btn btn-danger' type='submit'>
					{{ Form::hidden('_method', 'DELETE') }}
					<i class='glyphicon glyphicon-trash'></i> Delete
	    			</button>
					{{ Form::close() }}
				</td>
			</tr>
			@endforeach
</div>
@stop

