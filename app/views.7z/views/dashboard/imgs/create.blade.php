@extends('dashboard.master')
@section('content')
<div class="col-md-9">

	<h2>Upload Image to Gallery</h2>
	{{ Form::open(array('url' => 'imgs','files' => true)) }}
		<div>
		<li>	
			{{ Form::label('imgs', 'Image Description: ') }}
			{{ Form::text('imgs') }}
			</li><br>
			<li>
			{{ Form::label('img', 'Choose an image to upload ') }}
			{{ Form::file('img')}}
			</li><br>
			<li>


		</div>
		{{ Form::submit('Upload image') }}
	{{ Form::close() }}
</div>
@stop