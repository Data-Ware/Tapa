@extends('dashboard.master')
@section('content')
<div class="container">
<h2><strong>Gallery</strong></h2>
<div class="col-md-9">
<div>
<a href="{{ URL::to('imgs/create') }}" class="btn btn-success">Add item</a>
</div>
@foreach($imgs as $img)
	<div class="img col-xs-3">
	<p>{{ $img->desc }}</p>
	 <a target="_blank" href=" "><img src="{{$img->img_path}}" alt="{{$img->img_path}}" width="110" height="90"></a>
	 
	 <!-- <a href="{{ URL::to('imgs/' . $img->id_img) }}">show</a> -->
	 {{ Form::open(array('url' => 'imgs/' . $img->id_img)) }}
						<button class='btn btn-danger' type='submit'>
	 
	 {{ Form::hidden('_method', 'DELETE') }}
						<i class='glyphicon glyphicon-trash'></i> Delete</button>	    				
	 
	 {{ Form::close() }}
	</div>



@endforeach
</div>
@stop
