@extends('dashboard.master')
@section('content')
<div class="container">

<h2><strong>Gallery</strong></h2>
<div class="col-md-9">
<div class="img col-xs-3">
	<p>{{ $imgs->desc }}</p>
	 <a target="_blank" href="klematis_big.htm"><img src="{{$imgs->img_path}}" alt="{{$imgs->img_path}}" width="110" height="90"></a>
	</div>

</div>
@stop
