
@extends('dashboard.master')
@section('content')
<div class="container">

<h2><strong>Dashboard</strong></h2>
	<div class="row">
	<div class="col-md-9">
	Welcome (Admin Name)

<ul class="nav nav-tabs" role="tablist">
  <li class="active"><a href="#">Orders</a></li>
  <li><a href="#">Calander</a></li>
  <li><a href="#">Statictics</a></li>
   <li><a href="#">Helps</a></li>
</ul>


@stop	
	