@extends('dashboard.master')
@section('content')
<div class="col-md-9">

	<h2>New Item Create</h2>
	{{ Form::open(array('url' => 'items')) }}
		<div>
			{{ Form::label('item', 'Enter Description:') }}
			{{ Form::textarea('item') }}
		</div>
	
	{{ Form::submit('Save!', array('class' => 'btn btn-success')) }}	
	{{ Form::close() }}
</div>
	@stop