
@extends('dashboard.master')
@section('content')
<div class="col-md-9">
	<h2>Items Management</h2>
	<div>
	<a href="{{ URL::to('items/create') }}" class="btn btn-success">Add item</a>
	</div>
	<table border="1">
		<thead>
			<tr>
				<th> Item ID </th>
				<th> Items Description </th>
				<th>Edit</th>
				<th>Delete</th>
			</tr>
		</thead>
		<tbody>
			@foreach($items as $item)
			<tr>
				<td>{{ $item->id_item }}</td>
				<td>{{ $item->desc }}</td>

				<!-- <td><a href="{{ URL::to('items/' . $item->id_item) }}" class="btn btn-primary">Show</a></td> -->

				<td><a href="{{ URL::to('items/'. $item->id_item.'/edit') }}" class="btn btn-primary">Edit
			
				<td>
					
					{{ Form::open(array('url' => 'items/' . $item->id_item)) }}
					<button class='btn btn-danger' type='submit'>
					{{ Form::hidden('_method', 'DELETE') }}
					<i class='glyphicon glyphicon-trash'></i> Delete
	    			</button>
					{{ Form::close() }}
				</td>
			</tr>
			@endforeach
		
</div>
@stop