 

<div class="col-md-3">
	<ul>
		<li><a href="{{ URL::to('dashboard') }}">Dashboard</a></li>
		<li><a href="{{URL::to('caterings')}}">Edit Catering Page</a></li>

		
		<li><a href="{{URL::to('imgs')}}">Gallery</a></li>
		<li> <a href="{{URL::to('items')}}">Items</a></li>
		<li><a href="#">Accounts</a></li>
	</ul>
</div>