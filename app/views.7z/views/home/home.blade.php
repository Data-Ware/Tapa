@extends('layouts.default')

@section('content')

	<div id="main">
	<h1 style="margin-left: -10000px; display: hidden">tapa espresso, welcome to tapa espresso best catering in Hawthorn Victoria</h1>
	<p class="statement">tapa is a small &amp; friendly café &amp; caterer in Hawthorn, at tapa we believe in great coffee &amp; great food in a warm &amp; welcoming environment.</p>



@include("layouts.partials.tapacarousel")


@stop