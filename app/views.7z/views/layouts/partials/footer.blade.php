<div id="footer">
<img src="images/menuimages/footer_margin.jpg">
<!--
<p>design &copy;2011 pixel&amp;code&nbsp;&nbsp;|&nbsp;&nbsp;images by lisbeth grossman&nbsp;&nbsp;|&nbsp;&nbsp;<a class="link" href="contact_us.php">contact us</a> </p>
-->


<span class="text_l"><span style="font-size: 1.5em;">&copy;</span>2011 tapa cafe &amp; catering&nbsp;&nbsp;|&nbsp;&nbsp;website by pixel &amp; code&nbsp;&nbsp;|&nbsp;&nbsp;images by lisbeth grosmann</span>
<span class="text_r"><a class="link" href="contact">contact</a></span>
</div>
 </div><!-- End container -->
