<!-- here you can load or edit images for the main page carousel-->
<div id="slideshow" class="mainpic">
<img src="pix/catering/a7.jpg" alt="" width="564px" height="386px"/>
<img src="pix/catering/a8.jpg" alt="" width="564px" height="386px"/>
<img src="pix/catering/a9.jpg" alt="" width="564px" height="386px"/>
<img src="pix/catering/a10.jpg" alt="" width="564px" height="386px"/>
<img src="pix/catering/a11.jpg" alt="" width="564px" height="386px"/>
</div>