<div id="sidebar">
	<p class="address">31 burwood road<br />
hawthorn vic <br />mon - fri 6am - 4pm<br />
phone: 9818 8334<br />
<span class="menu"><a href="mailto:tapa@iinet.net.au" class="contact">tapa@iinet.net.au</a></span>
<div class="sidetext">
    <p>tapa: an unwoven cloth made by people in the pacific islands from the inner bark of the paper mulberry tree.
    <p>In tonga, tapa is of special significance to its people; at tapa we hope to make our customers feel special too.</p>
</div>
</div>