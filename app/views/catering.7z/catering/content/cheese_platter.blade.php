<div class="block">

<!--Content Goes Here-->
    <div class="acc_content_head">
        <span class="lh3">{{ $blockHeader->find(39)->header }}</span><span class="rh3">{{ $blockHeader->find(39)->price }}</span>
    </div>
    <div class="menu_l">
        <ul>
            <li>{{$item->find(51)->desc }}</li>
        </ul>        
    </div>    
    <div class="menu_r">
        <div id="gallery">
            <ul>
                <li>
                    <a href="{{$img->find(6)->a_path}}" title="cheese platter">
                        <img src="images/menuthumbs/menuthmb03.jpg"alt="cheese platter" />
                    </a>
                </li>
            </ul>
        </div>
    </div>
 
</div>


