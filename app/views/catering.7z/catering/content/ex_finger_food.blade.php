<div class="block">
    <!--Content Goes Here-->
    <div class="acc_content_head">
        <span class="lh3">{{ $blockHeader->find(35)->header }}</span><span class="rh3">{{ $blockHeader->find(35)->price }}</span>
    </div>
        <div class="menu_l">
        <ul>
            <li>{{$item->find(36)->desc }}</li>
             <li>{{$item->find(37)->desc }}</li>
             <li>{{$item->find(38)->desc }}</li>
             <li>{{$item->find(39)->desc }}</li>
             <li>{{$item->find(40)->desc }}</li>
        </ul>
        </div>
        <div class="menu_r">
            <div id="gallery">
                <ul>
                    <li>
                       <!--<a href="images/menuimages/menupix_18.jpg" title="mediterranean frittata slice">
                            <img src="images/menuthumbs/menuthmb18.jpg"alt="mediterranean frittata slice" />
                        </a>-->
                        <!--<li>
                        <a href="images/menuimages/menupix_06.jpg" title="mushroom arancini">
                            <img src="images/menuthumbs/menuthmb06.jpg"alt="mushroom arancini" />
                        </a>
                    </li>-->
                    <li> 
                        <a href="{{$img->find(6)->a_path}}" title="{{$img->find(2)->alt}}">
                        <img src="{{$img->find(2)->img_path}}"alt="{{$img->find(2)->alt}}" />
                      </a> 
                    </li>
                    <li>                    
                       <a href="{{$img->find(6)->a_path}}" title="{{$img->find(2)->alt}}">
                        <img src="{{$img->find(2)->img_path}}"alt="{{$img->find(2)->alt}}" />
                      </a> 
                    </li>
                  <!--<li>
                        <a href="images/menuimages/menupix_06.jpg" title="mushroom arancini">
                            <img src="images/menuthumbs/menuthmb06.jpg"alt="mushroom arancini" />
                        </a>
                    </li>-->
                    <li>
                        <a href="images/menuimages/menupix_16.jpg" title="sausage rolls">
                            <img src="images/menuthumbs/menuthmb16.jpg"alt="sausage rolls" />
                        </a>
                    </li>
                    <li>
                        <a href="images/menuimages/menupix_05.jpg" title="mini quiches">
                            <img src="images/menuthumbs/menuthmb05.jpg"alt="mini quiches" />
                        </a>
                    </li>
                </ul>
            </div>        
        </div>
</div>
    <script type="text/javascript">
    $(function() {
        $('#gallery a').lightBox();
    });
    </script>
