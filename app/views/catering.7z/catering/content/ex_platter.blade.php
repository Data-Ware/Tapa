<div class="block">
   <?php //echo $item ?>
    <!--Content Goes Here-->
    <div class="acc_content_head">
        <span class="lh3">{{ $blockHeader->find(25)->header }}</span><span class="rh3">{{ $blockHeader->find(25)->price }}</span>
        <div style="clear: both;"></div>

        <span class="lh3">{{ $blockHeader->find(26)->header }}<span style="font-size: 0.8em;">&nbsp;-&nbsp;{{ $blockHeader->find(26)->sub_header }} </span></span><span class="rh3">{{ $blockHeader->find(26)->price }}</span>

                        
    </div>
        <div class="menu_l">
        <ul>
            <li>{{$item->find(1)->desc }}</li>
            <li>{{$item->find(2)->desc }}</li>
            <li>{{$item->find(3)->desc }}</li>
            <li>{{$item->find(4)->desc }}</li>
            <li>{{$item->find(5)->desc }}</li>
            <li>{{$item->find(6)->desc }}</li>
            <li>{{$item->find(7)->desc }}</li>
        </ul>
    </div>
    <div class="menu_r">
        <div id="gallery">
            <ul>
                <li>
                    
                    <a href="{{$img->find(6)->a_path}}"title="{{$img->find(6)->title}}">
                        <img src="{{$img->find(6)->img_path}}"alt="{{$img->find(6)->alt}}" />
                    </a>
                </li>
            </ul>
        </div>
    
    </div>
</div>
    <script type="text/javascript">
    $(function() {
        $('#gallery a').lightBox();
    });
    </script>
   	
