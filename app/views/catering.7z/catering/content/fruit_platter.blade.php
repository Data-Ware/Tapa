<div class="block">
    <div class="acc_content_head">
        <span class="lh3">{{ $blockHeader->find(38)->header }}</span><span class="rh3">{{ $blockHeader->find(38)->price }}</span>
    </div>
    <div class="menu_l">
        <ul>
            <li>{{$item->find(50)->desc }}</li>
        </ul>       
    </div>    
    <div class="menu_r">
        <div id="gallery">
            <ul>
                <li>
                    <a href="images/menuimages/menupix_23.jpg" title="seasonal fruit platter">
                        <img src="images/menuthumbs/menuthmb23.jpg"alt="seasonal fruit platter" />
                    </a>
                </li>
            </ul>
        </div>
    
    </div>
</div>
