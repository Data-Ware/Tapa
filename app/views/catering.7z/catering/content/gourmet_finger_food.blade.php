<div class="block">

        <div class="acc_content_head">
        <span class="lh3">{{ $blockHeader->find(36)->header }}</span><span class="rh3">{{ $blockHeader->find(25)->price }}</span>
    </div>
    <div class="menu_l">
        <ul>
            <li>{{$item->find(41)->desc }}</li>
            <li>{{$item->find(42)->desc }}</li>
            <li>{{$item->find(43)->desc }}</li>
            <li>{{$item->find(44)->desc }}</li>
            <li>{{$item->find(45)->desc }}</li>
            <li>{{$item->find(46)->desc }}</li>
            <li>{{$item->find(47)->desc }}</li>
        </ul>       
    </div>    
    <div class="menu_r">
            <div id="gallery">
                <ul>
                    <li>
                        <a href="images/menuimages/menupix_17.jpg" title="smoked salmon blinis with creme fraiche">
                            <img src="images/menuthumbs/menuthmb17.jpg"alt="smoked salmon blinis with creme fraiche" />
                        </a>
                    </li>
                    <li>
                        <a href="images/menuimages/menupix_15.jpg" title="thai chicken skewers">
                            <img src="images/menuthumbs/menuthmb15.jpg"alt="thai chicken skewers" />
                        </a>
                    </li>
                </ul>
            </div>
    </div>
    
    <div style="clear: both;" class="acc_content_head item_head">
        <span class="lh3">{{ $blockHeader->find(37)->header }}</span><span class="rh3">{{ $blockHeader->find(37)->price }}</span>
    </div>
    <div class="menu_l">
        <ul>
            <li>{{$item->find(48)->desc }}</li>
            <li>{{$item->find(49)->desc }}</li>
        </ul>
    </div>
    <div class="menu_r">
            <div id="gallery">
                <ul>
                    <li>
                        <a href="images/menuimages/menupix_13.jpg" title="mini beef burgers">
                            <img src="images/menuthumbs/menuthmb13.jpg"alt="mini beef burgers" />
                        </a>
                    </li>
                </ul>
            </div>    
    </div>    
</div>
    <script type="text/javascript">
    $(function() {
        $('#gallery a').lightBox();
    });
    </script>