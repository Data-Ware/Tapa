<div class="block">
    <!--Content Goes Here-->
    <div class="acc_content_head">
        <span class="lh3">{{ $blockHeader->find(27)->header }}</span><span class="rh3">{{ $blockHeader->find(27)->price }}</span>
        <div style="clear: both;"></div>
        <span class="lh3">{{ $blockHeader->find(28)->header }} <span class="h3small">{{ $blockHeader->find(28)->sub_header }}</span></span><span class="rh3">{{ $blockHeader->find(28)->price }}</span>
                    
    </div>
    <div class="menu_l">
    <ul>
         <li>{{$item->find(8)->desc }}</li>
           <li>{{$item->find(9)->desc }}</li>
           <li>{{$item->find(10)->desc }}</li>
           <li>{{$item->find(11)->desc }}</li>
           <li>{{$item->find(13)->desc }}</li>
           <li>{{$item->find(14)->desc }}</li>
           <li>{{$item->find(15)->desc }}</li>
           <li>{{$item->find(16)->desc }}</li>
           <li>{{$item->find(17)->desc }}</li>
           <li>{{$item->find(18)->desc }}</li>

        </ul>
    </div>
    <div class="menu_r">
        <div id="gallery">
            <ul>
                <li>
                   <!-- <a href="images/menuimages/menupix_01.jpg" title="gourmet sandwiches and rolls">
                        <img src="images/menuthumbs/menuthmb01.jpg"alt="gourmet sandwiches and rolls" />
                    </a>-->

                  <a href="{{$img->find(6)->a_path}}" title="{{$img->find(2)->alt}}">
                        <img src="{{$img->find(2)->img_path}}"alt="{{$img->find(2)->alt}}" />
                    </a>


                </li>
            </ul>
        </div>
    
    </div>
    <script type="text/javascript">
    $(function() {
        $('#gallery a').lightBox();
    });
    </script>
   	
</div>