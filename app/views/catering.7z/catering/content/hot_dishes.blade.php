<div class="block">
<!--Content Goes Here-->
    <div class="acc_content_head">
        <span class="lh3">{{ $blockHeader->find(29)->header }}<span style="font-size: 0.8em;"> {{ $blockHeader->find(29)->sub_header }}</span></span><span class="rh3">{{ $blockHeader->find(29)->price }}</span>
        <div style="clear: both;"></div>
        <span class="lh3">{{ $blockHeader->find(30)->header }}<span style="font-size: 0.8em;">  {{ $blockHeader->find(30)->sub_header }}</span></span><span class="rh3">{{ $blockHeader->find(30)->price }}</span>
                    
    </div>

    <div class="menu_l">
        <ul>
            <li>{{$item->find(19)->desc }}</li>
            <li>{{$item->find(20)->desc }}</li>
            <li>{{$item->find(21)->desc }}</li>
            <li>{{$item->find(22)->desc }}</li>
            <li>{{$item->find(23)->desc }}</li>
            <li>{{$item->find(24)->desc }}</li>
            <li>{{$item->find(25)->desc }}</li>
        </ul>
        
    </div>
    <div class="menu_r">
        <div id="gallery">
            <ul>
                <li>
                    <a href="images/menuimages/menupix_08.jpg" title="noodle box">
                        <img src="images/menuthumbs/menuthmb08.jpg"alt="noodle box" />
                    </a>
                </li>
            </ul>
        </div>
    </div>
   
</div>

