<div class="block">

    <div class="acc_content_head">
        <span class="lh3">muffins mini or regular</span><span class="rh3">$1.00/$2.50 each</span>
    </div>
    <div class="menu_l">
        <ul>
            <li>{{$item->find(52)->desc }}</li>
        </ul>      
    </div>    
    <div class="menu_r">
            <div id="gallery">
                <ul>
                    <li>
                        <a href="images/menuimages/menupix_19.jpg" title="homemade muffins">
                            <img src="images/menuthumbs/menuthmb19.jpg"alt="homemade muffins" />
                        </a>
                    </li>
                </ul>
            </div>    
    </div>
    
    
    <div style="clear: both;" class="acc_content_head item_head">
        <span class="lh3">muffin/slice combination</span><span class="h3small"></span> <span class="rh3">$4.00 per person</span>
    </div>
    <div class="menu_l">
        <ul>
            <li{{$item->find(53)->desc }}</li>
        </ul>
    </div>
    <div class="menu_r">
            <div id="gallery">
                <ul>
                    <li>
                        <a href="images/menuimages/menupix_21.jpg" title="muffins and slices">
                            <img src="images/menuthumbs/menuthmb21.jpg"alt="muffins and slices" />
                        </a>
                    </li>
                </ul>
            </div>    
    </div> 
    <div style="clear: both;" class="acc_content_head item_head">
        <span class="lh3">scones<span style="font-size: 0.8em;"> - 12 hours notice required</span></span><span class="rh3">$2.50 each</span>
    </div>   
    <div class="menu_l">
        <ul>
            <li>{{$item->find(54)->desc }}</li>
        </ul>
    </div>
    <div style="clear: both;" class="acc_content_head item_head">
        <span class="lh3">fruit pastries mini or regular<span style="font-size: 0.8em;"> - 24 hours notice required</span></span><span class="rh3">$2.00/$3.00 each</span>
    </div>   
    <div class="menu_l">
        <ul>
            <li>{{$item->find(55)->desc }}</li>
        </ul>
    </div>
    <div class="menu_r">
            <div id="gallery">
                <ul>
                    <li>
                        <a href="images/menuimages/menupix_20.jpg" title="fruit pasteries">
                            <img src="images/menuthumbs/menuthmb20.jpg"alt="fruit pasteries" />
                        </a>
                    </li>
                </ul>
            </div>       
    </div>
    <div style="clear: both;" class="acc_content_head item_head">
        <span class="lh3">croissants mini or regular<span style="font-size: 0.8em;"> - 24 hours notice required</span></span> <span class="rh3">$2.00/$3.00 each</span>
    </div>   
    <div class="menu_l">
        <ul>
            <li>{{$item->find(56)->desc }}</li>
        </ul>
    </div>
    <div style="clear: both;" class="acc_content_head item_head">
        <span class="lh3">filled croissants mini or regular<span style="font-size: 0.8em;"> - 24 hours notice required</span></span><span class="rh3">$3.00/$5.00 each</span>
    </div>   
    <div class="menu_l">
        <ul>
           <li>{{$item->find(57)->desc }}</li>
             <li>{{$item->find(101)->desc }}</li>
        </ul>
    </div>
    <div class="menu_r">
            <div id="gallery">
                <ul>
                    <li>
                        <a href="images/menuimages/menupix_22.jpg" title="cheese and tomato croissants">
                            <img src="images/menuthumbs/menuthmb22.jpg"alt="cheese and tomato croissants" />
                        </a>
                    </li>
                </ul>
            </div>       </div>
    <div style="clear: both;" class="acc_content_head item_head">
        <span class="lh3">bacon &amp; egg english muffins</span> <span class="rh3">$4.00 each</span>
    </div>   
    <div class="menu_l">
        <ul>
            <li>{{$item->find(58)->desc }}</li>
        </ul>
    </div>
    <div style="clear: both;" class="acc_content_head item_head">
        <span class="lh3">large cakes<span style="font-size: 0.8em;"> - 24 hours notice required</span></span> <span class="rh3">$30 - $40</span>
    </div>   
    <div class="menu_l">
        <ul>
            <li>{{$item->find(59)->desc }}</li>
        </ul>
    </div>
 </div>                             