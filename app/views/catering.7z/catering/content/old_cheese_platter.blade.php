<div class="block">

<!--Content Goes Here-->
    <div class="acc_content_head">
        <span class="lh3">{{ $blockHeader->find(33)->header }}</span><span class="rh3">{{ $blockHeader->find(33)->price }}</span>
    </div>
    <div class="menu_l">
        <ul>
            <li>{{$item->find(34)->desc }}</li>
        </ul>        
    </div>    
    <div class="menu_r">
        <div id="gallery">
            <ul>
                <li>
                    <a href="images/menuimages/menupix_02.jpg" title="executive platter <br>baguette, turkish & mixed bread ">
                        <img src="images/menuthumbs/menuthmb02.jpg"alt="" />
                    </a>
                </li>
            </ul>
        </div>
    </div>
 
    
    <div style="clear: both;" class="acc_content_head item_head">
        <span class="lh3">{{ $blockHeader->find(34)->header }}</span><span class="rh3">{{ $blockHeader->find(34)->price }}</span>
    </div>
    <div class="menu_l">
        
        <ul>
           <li>{{$item->find(35)->desc }}</li>
        </ul>
    </div>
    <div class="menu_r">
        <div id="gallery">
            <ul>
                <li>
                    <a href="images/menuimages/menupix_14.jpg" title="executive platter <br>baguette, turkish & mixed bread ">
                        <img src="images/menuthumbs/menuthmb14.jpg"alt="" />
                    </a>
                </li>
            </ul>
        </div>    
    </div>
 </div>

