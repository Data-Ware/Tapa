<div class="block">

    <!--Content Goes Here-->
    <div class="acc_content_head">
        <span class="lh3">{{ $blockHeader->find(32)->header }}</span><span class="rh3">{{ $blockHeader->find(32)->price }}</span>  
    </div>
    <div class="menu_l">
        <ul>
             <li>{{$item->find(30)->desc }}</li>
            <li>{{$item->find(31)->desc }}</li>
            <li>{{$item->find(32)->desc }}</li>
            <li>{{$item->find(32)->desc }}</li>
        </ul>
    </div>
    <div class="menu_r">
            <div id="gallery">
                <ul>
                    <li>
                        <a href="images/menuimages/menupix_09.jpg" title="thai noodle salad">
                            <img src="images/menuthumbs/menuthmb09.jpg"alt="thai noodle salad" />
                        </a>
                    </li>
                    <li>
                        <a href="images/menuimages/menupix_11.jpg" title="roast pumpkin pinenut spinach and pasta">
                            <img src="images/menuthumbs/menuthmb12.jpg"alt="roast pumpkin pinenut spinach and pasta" />
                        </a>
                    </li>
                    <li>
                        <a href="images/menuimages/menupix_10.jpg" title="cous cous salad">
                            <img src="images/menuthumbs/menuthmb10.jpg"alt="" />
                        </a>
                    </li>
                </ul>
            </div>
    </div>
</div>
    <script type="text/javascript">
    $(function() {
        $('#gallery a').lightBox();
    });
    </script>