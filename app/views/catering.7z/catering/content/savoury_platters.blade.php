<div class="block">

<!--Content Goes Here-->
    <div class="acc_content_head">
        <span class="lh3">{{ $blockHeader->find(33)->header }}</span><span class="rh3">{{ $blockHeader->find(33)->price }}</span>
    </div>
    <div class="menu_l">
        <ul>
            <li>{{$item->find(34)->desc }}</li>
        </ul>        
    </div>    
    <div class="menu_r">
        <div id="gallery">
            <ul>
                <li>
                   <!--<a href="images/menuimages/menupix_02.jpg" title="turkish bread and dips">
                        <img src="images/menuthumbs/menuthmb02.jpg"alt="turkish bread and dips" />
                    </a>-->
                    <a href="{{$img->find(6)->a_path}}"title="{{$img->find(6)->title}}">
                        <img src="{{$img->find(6)->img_path}}"alt="{{$img->find(6)->alt}}" />
                    </a>
                </li>
            </ul>
        </div>
    </div>
 
    
    <div style="clear: both;" class="acc_content_head item_head">
        <span class="lh3">{{ $blockHeader->find(34)->header }}</span><span class="rh3">{{ $blockHeader->find(34)->price }}</span>
    </div>
    <div class="menu_l">
        
        <ul>
            <li>{{$item->find(35)->desc }}</li>
        </ul>
    </div>
    <div class="menu_r">
        <div id="gallery">
            <ul>
                <li>
                    <!--<a href="images/menuimages/menupix_14.jpg" title="antipasto platter">
                        <img src="images/menuthumbs/menuthmb14.jpg"alt="antipasto platter" />-->

                      <a href="{{$img->find(6)->a_path}}"title="{{$img->find(6)->title}}">
                        <img src="{{$img->find(6)->img_path}}"alt="{{$img->find(6)->alt}}" />  
                    </a>
                </li>
            </ul>
        </div>    
    </div>
 </div>

