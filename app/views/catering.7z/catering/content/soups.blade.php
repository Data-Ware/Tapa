<div class="block">

    <!--Content Goes Here-->
    <div class="acc_content_head">
        <span class="lh3">{{ $blockHeader->find(31)->header }}</span><span class="rh3">{{ $blockHeader->find(31)->price }}</span>  
    </div>
    <div class="menu_l">
    <ul>
       <li>{{$item->find(26)->desc }}</li>
        <li>{{$item->find(27)->desc }}</li>
        <li>{{$item->find(28)->desc }}</li>
        <li>{{$item->find(29)->desc }}</li>
        </ul>
    </div>
 
</div>