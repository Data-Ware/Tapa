@foreach ( $cat as $c )
<a href="#">{{ $c->desc }}</a>



@foreach ($c->blocks as $block)



	@foreach ( $block->blockheaders as $bh )
	<span class="lh3">{{ $bh->header }}<span style="font-size: 0.8em;"> {{ $bh->sub_header }}</span></span><span class="rh3">{{ $bh->price }}</span>
	@endforeach
	@foreach ( $block->items as $i )
	<li>{{ $i->desc }}</li>
	@endforeach
	@foreach ( $block->imgs as $i )
	<a href="{{$i->a_path}}" title="{{$i->title}}">
	    <img src="{{$i->img_path}}"alt="{{$i->alt}}" />
	</a>
	@endforeach



@endforeach



@endforeach