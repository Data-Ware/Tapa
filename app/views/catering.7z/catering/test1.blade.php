@foreach ( $block as $b )
<a href="#">{{ $b->categories->desc }}</a>
@foreach ( $b->blockheaders as $bh )
<span class="lh3">{{ $bh->header }}<span style="font-size: 0.8em;"> {{ $bh->sub_header }}</span></span><span class="rh3">{{ $bh->price }}</span>
@endforeach
@foreach ( $b->items as $i )
<li>{{ $i->desc }}</li>
@endforeach
@foreach ( $b->imgs as $i )
<a href="{{$i->a_path}}" title="{{$i->title}}">
    <img src="{{$i->img_path}}"alt="{{$i->alt}}" />
</a>
@endforeach
@endforeach